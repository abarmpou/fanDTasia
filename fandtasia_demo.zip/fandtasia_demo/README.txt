
%-DISCLAIMER-------------------------------------------------------------------------
% If you want to use this dataset in a scientific publication (journal or conference
% proceedings) you need to ask permission from Dr.Barmpoutis (abarmpou@cise.ufl.edu).
%
% You can use this dataset for non commercial research and educational purposes 
% only. You cannot repost this file without prior written permission from the 
% authors.
%
% Angelos Barmpoutis, PhD
% Computer and Information Science and Engineering Department
% University of Florida, Gainesville, FL 32611, USA
% abarmpou at cise dot ufl dot edu
%------------------------------------------------------------------------------------
